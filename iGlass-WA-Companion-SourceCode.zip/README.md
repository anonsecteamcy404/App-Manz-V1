# iGlass WA Companion - Linked Device & Auto Exporter

Aplikasi Full-Stack WhatsApp Companion (Perangkat Tertaut) dengan antarmuka **Apple iOS Liquid Glassmorphism** dan sistem **Ekspor Otomatis & Manual** (ZIP, HTML, JSON, TXT) menggunakan **Express + Vite + React 19 + Tailwind CSS v4 + @whiskeysockets/baileys**.

## Cara Menjalankan & Build Secara Lokal

Pastikan Anda telah menginstal **Node.js v20+ (direkomendasikan v22 LTS)**.

### 1. Instal Dependensi
```bash
npm install
```

### 2. Jalankan Mode Development (Full-Stack Server + Vite)
```bash
npm run dev
```
Buka `http://localhost:3000` di browser Anda.

### 3. Build untuk Production
```bash
npm run build
```

### 4. Jalankan Server Production
```bash
NODE_ENV=production npm start
```
