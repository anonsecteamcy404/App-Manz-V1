# iGlass WA Companion - Real Multi-Device + Mod & Anti-Ban Edition

Aplikasi Full-Stack WhatsApp Companion (Perangkat Tertaut Real) dengan antarmuka **Apple iOS Liquid Glassmorphism**, fitur **Mod Privasi & Anti-Ban**, **Chat Boom**, **Pembuka Foto/Video 1x Lihat**, **Pengunduh Status**, dan **Ekspor Otomatis**.

## Cara Menjalankan & Build Secara Lokal

Pastikan Anda telah menginstal **Node.js v20+ (direkomendasikan v22 LTS)**.

### 1. Instal Dependensi
```bash
npm install
```

### 2. Jalankan Server Full-Stack
```bash
npm run dev
```
Buka `http://localhost:3000` di browser Anda, lalu scan QR Code menggunakan aplikasi WhatsApp di HP Anda.
